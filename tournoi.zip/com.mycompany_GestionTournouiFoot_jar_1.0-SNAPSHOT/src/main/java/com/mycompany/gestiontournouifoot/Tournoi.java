/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestiontournouifoot;
import java.util.* ;

/**
 *
 * @author hp
 */
public class Tournoi {
    private String nom;
    private List<Equipe> equipes;
    private List<Match> matchs;

    public Tournoi(String nom) {
        this.nom = nom;
        this.equipes = new ArrayList<>();
        this.matchs = new ArrayList<>();
    }

    public void ajouterEquipe(Equipe equipe) {
        equipes.add(equipe);
    }
      public void afficherGangantstatic() {
    
    
}

   

    
}
